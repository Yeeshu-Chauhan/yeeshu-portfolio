import React from 'react'
import './Footer.css'
import {BsLinkedin} from 'react-icons/bs'
import {FiInstagram} from 'react-icons/fi'
import {IoLogoTwitter} from 'react-icons/io'

const footer = () => {
  return (
    <footer>
      <a href="" className="footer_logo">Yeeshu</a>


      <ul className="permalinks">
        <li><a href="#">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a target={'_blank'} href="https://www.meity.gov.in/content/information-technology-act-2000">Service Policy</a></li>
        <li><a href="#testimonials">Testimonials</a></li>
        <li><a target={'_blank'} href="https://api.whatsapp.com/send/?phone=919575068626">Charity Donation</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a target={'_blank'} href="https://maps.app.goo.gl/nAoTYb4FXDaPUPFo8">My Blogs</a></li>
      </ul>

      <div className="footer_socials">
        <a target={'_blank'} href="https://www.linkedin.com/in/yeeshu-chauhan"><BsLinkedin/></a>
        <a target={'_blank'} href="https://www.instagram.com/p/CcLNyadq1LlQmc1wGE6WFaoctdBID09Y3rVe5g0/?igshid=YmMyMTA2M2Y="><FiInstagram/></a>
        <a target={'_blank'} href="https://twitter.com/___yeeshu___?t=W66iL1TbkYhZBBwrlCiT6g&s=09"><IoLogoTwitter/></a>
      </div>

      <div className="footer_copyright">
        <small>&copy; Yeeshu Chauhan | All Rights Reserved.</small>
      </div>
    </footer>
  )
}

export default footer