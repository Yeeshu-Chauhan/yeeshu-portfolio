import React from "react";
import {BsLinkedin} from 'react-icons/bs'
import {FaGithub} from 'react-icons/fa'
import {FiInstagram} from 'react-icons/fi'

const HeaderSocials = () => {
    return(
        <div className="header_socials">
            <a href="https://www.linkedin.com/in/yeeshu-chauhan" target="_blank"><BsLinkedin/></a>
            <a href="https://github.com/Yeeshu-Chauhan" target="_blank"><FaGithub/></a>
            <a href="https://www.instagram.com/p/CcLNyadq1LlQmc1wGE6WFaoctdBID09Y3rVe5g0/?igshid=YmMyMTA2M2Y=" target="_blank"><FiInstagram/></a>
        </div>
    )
}

export default HeaderSocials