import React from 'react'
import './Experience.css'
import { BsPatchCheckFill } from 'react-icons/bs'

const Experience = () => {
  return (
    <section id='experience'>
      <h5>Skills I Have</h5>
      <h2>My Experience</h2>
      <div className="container experience_container">
        <div className="experience_frontend">
          <h3>Web Development</h3>
          <div className="experience_content">
            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>HTML5, CSS3, JavaScript</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Bootstrap, TailwindCSS</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>NodeJS, ExpressJS</h4>
                <small className="text_light">Beginner</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>ReactJS, Material UI</h4>
                <small className="text_light">Intermediate</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Mongodb, NOSQL</h4>
                <small className="text_light">Beginer</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Python, SQL</h4>
                <small className="text_light">Beginer</small>
              </div>
            </article>
          </div>
        </div>





        <div className="experience_backend">
          <h3>Social Media Desgining</h3>
          <div className="experience_content">
            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Adobe</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Canva</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>VegasPro</h4>
                <small className="text_light">Intermediate</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Insta/Facebook</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>

            <article className="experience_details">
              <BsPatchCheckFill className='experience_details-icons' />
              <div>
                <h4>Youtube</h4>
                <small className="text_light">Experienced</small>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Experience