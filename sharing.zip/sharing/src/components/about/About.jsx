import React from 'react'
import './About.css'
import ME from '../../assets/ME.jpg'
import {FaAward} from 'react-icons/fa'
import {FiUser} from 'react-icons/fi'
import {VscFolderLibrary} from 'react-icons/vsc'

const About = () => {
  return (
    <section id='about'>
      <h5>Get To Know</h5>
      <h2>About Me</h2>

      <div className="container about_container">
        <div className="about_me">
          <div className="about_me-img">
            <img src={ME} alt="About Image" />
          </div>
        </div>

        <div className="about_content">
          <div className="about_cards">
            <article className='about_card'>
              <FaAward className='about_icon'/>
              <h5>Experience</h5>
              <small>12+ Months Working</small>
            </article>

            <article className='about_card'>
              <FiUser className='about_icon'/>
              <h5>Clients</h5>
              <small>15+ World Wide</small>
            </article>

            <article className='about_card'>
              <VscFolderLibrary className='about_icon'/>
              <h5>Projects</h5>
              <small>10+ Completed</small>
            </article>
          </div>
          <p>
          It's my learning phase, so I am actively learning new things and technologies. Working on Web Development, I am very good at UI Designing with HTML5, CSS3, 
            JavaScript and JavaScript frameworks like ReactJs. I do backend coding also but in deep of my heart, I feel that instead of backend development I am an expert in Frontend, 
            because it is more important to attract customers. I believe Jo Deekhta Hai Wo Beekta Hai (People will buy 
            a product if It's good looking no matter what's on the back side it should be attractive in front).
          </p>
          <p>
          You might have read Explorer in the heading. So yes exploring Google Maps is my hobby and I have explored more than 52 cities. You can connect with me on Google Maps, just check my reviews in the Blog section.
          </p>

          <a href="#contact" className='btn btn-primary'>Let's Talk</a>
        </div>
      </div>
    </section>
  )
}

export default About