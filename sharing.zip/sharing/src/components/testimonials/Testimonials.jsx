import React from 'react'
import './Testimonials.css'
import AVTR1 from '../../assets/avt1.jpg'
import AVTR2 from '../../assets/avt2.jpg'
import AVTR3 from '../../assets/avt3.jpg'
import AVTR4 from '../../assets/avt4.jpg'

// import Swiper core and required modules
import { Pagination } from 'swiper';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';


const data = [
  {
    avatar: AVTR1,
    name: 'Jhalak Dutta',
    review: 'Yeeshu is a great person to his work, he love the job he does. I have cotacted him many times to design various cards for my day to day work, he really makes very awesom designs.'
  }
,
  {
    avatar: AVTR2,
    name: 'Maj Gen VPS Bhakuni',
    review: 'Yeeshu Chauhan is very well focused and creative person. He makes really awesom designs he worked with us as a freelancer, and helped to grow our social media with creative and unique designs.'
  }
,
  {
    avatar: AVTR4,
    name: 'Sakshi Dixit',
    review: 'Yeeshu built a personal portfolio website for me and it looks pretty cool, he also makes awesom posters for me. He is very kind and helping person.'
  }
,
  {
    avatar: AVTR3,
    name: 'Nitin Singh',
    review: 'I met Yeeshu couple of years ago, he helped me to grow my social accounts and as he recently learned webdevelopment so now a days he is helping me to build a website for my organisation. Yeeshu is best in his job.'
  }
]

const Testimonials = () => {
  return (
    <section id='testimonials'>
      <h5>Review From Clients</h5>
      <h2>Testimonials</h2>

      <Swiper className="container testimonials_container" 
      modules={[Pagination]}
      spaceBetween={40}
      slidesPerView={1}
      pagination={{ clickable: true }}
      >
        {
          data.map(({avatar, name, review}, index) => {
            return(
              <SwiperSlide key={index} className='testimonial'>
                <div className="client_avatar">
                  <img src={avatar}  />
                </div>
                <h5 className="client_name">{name}</h5>
                <small className="client_review">{review}</small>
              </SwiperSlide>
            )
          })
        }
      </Swiper>
    </section>
  )
}

export default Testimonials